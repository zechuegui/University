package com.example.toDoList43017

data class ModeloTarefa(var checked: Boolean, var texto: String){

}


