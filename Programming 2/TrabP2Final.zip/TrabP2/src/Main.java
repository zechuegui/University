public class Main {
    public static void main (String[]args){

        Interface fun = new Interface();
        fun.run();
    }


}


