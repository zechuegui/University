public abstract class TurtleStatement {
    public abstract void run(Interpreter interpreter);
}
